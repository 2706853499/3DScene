
#include "Face.h"

Face::Face()
{
}

Face::~Face()
{
}